CREATE DATABASE Equipos;

USE Equipos;

drop table equipos;

CREATE TABLE equipos(
  nombre varchar(100) NOT NULL PRIMARY KEY,
  escudo varchar(100),
  descripcion varchar(200)
);

insert into equipos values("Atletico de Madrid", "AtleticoMadrid.png", "El Club Atletico de Madrid actualmente juega en el Estadio Wanda Metropolitano");
insert into equipos values("Barcelona", "Barcelona.png", "El Club Barcelona actualmente juega en el Estadio Camp Nou");
insert into equipos values("Real Madrid", "RealMadrid.png", "El Real Madrid Club de Futbol actualmente juega en el Santiago Bernabeu");