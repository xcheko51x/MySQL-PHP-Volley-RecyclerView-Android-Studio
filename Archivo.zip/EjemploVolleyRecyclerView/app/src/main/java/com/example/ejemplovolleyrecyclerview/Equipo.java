package com.example.ejemplovolleyrecyclerview;

import java.io.Serializable;

public class Equipo implements Serializable {

    private String nombre;
    private String escudo;
    private String descripcion;

    public Equipo(String nombre, String escudo, String descripcion) {
        this.nombre = nombre;
        this.escudo = escudo;
        this.descripcion = descripcion;
    }

    public String getNombre() { return nombre; }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEscudo() {
        return escudo;
    }

    public void setEscudo(String escudo) {
        this.escudo = escudo;
    }

    public String getDescripcion() { return descripcion; }

    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}
