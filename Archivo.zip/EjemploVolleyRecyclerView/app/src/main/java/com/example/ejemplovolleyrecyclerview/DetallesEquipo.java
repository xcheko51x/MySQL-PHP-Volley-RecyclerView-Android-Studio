package com.example.ejemplovolleyrecyclerview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class DetallesEquipo extends AppCompatActivity {

    ImageView ivEscudo;
    TextView tvNombre, tvDescripcion;

    Equipo equipo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles_equipo);

        ivEscudo = findViewById(R.id.ivEscudo);
        tvNombre = findViewById(R.id.tvNombreEquipo);
        tvDescripcion = findViewById(R.id.tvDescripcion);

        equipo = (Equipo) getIntent().getExtras().getSerializable("equipo");

        Picasso.get().load("http://192.168.0.11/Equipos/"+equipo.getEscudo())
                .resize(400, 500)
                .into(ivEscudo);

        tvNombre.setText(equipo.getNombre());
        tvDescripcion.setText(equipo.getDescripcion());

    }
}
