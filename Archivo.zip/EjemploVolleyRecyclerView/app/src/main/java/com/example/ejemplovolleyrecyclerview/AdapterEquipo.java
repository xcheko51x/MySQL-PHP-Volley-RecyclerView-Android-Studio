package com.example.ejemplovolleyrecyclerview;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class AdapterEquipo extends RecyclerView.Adapter<AdapterEquipo.ViewHolderEquipos> {

    Context context;
    ArrayList<Equipo> listaEquipos;

    public AdapterEquipo(Context context, ArrayList<Equipo> listaEquipos) {
        this.context = context;
        this.listaEquipos = listaEquipos;
    }

    @NonNull
    @Override
    public ViewHolderEquipos onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_rv_equipo, null, false);

        return new ViewHolderEquipos(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolderEquipos viewHolderEquipos, final int i) {
        Picasso.get().load("http://192.168.0.11/Equipos/"+listaEquipos.get(i).getEscudo()).resize(400, 500).into(viewHolderEquipos.ivEscudo);
        viewHolderEquipos.tvNombre.setText(listaEquipos.get(i).getNombre());

        viewHolderEquipos.ivEscudo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(), "SELECCIONO "+listaEquipos.get(i).getNombre(), Toast.LENGTH_LONG).show();

                Intent intent = new Intent(v.getContext(), DetallesEquipo.class);
                intent.putExtra("equipo", listaEquipos.get(i));
                context.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return listaEquipos.size();
    }

    public class ViewHolderEquipos extends RecyclerView.ViewHolder {

        ImageView ivEscudo;
        TextView tvNombre;

        public ViewHolderEquipos(@NonNull View itemView) {
            super(itemView);

            ivEscudo = itemView.findViewById(R.id.ivEscudo);
            tvNombre = itemView.findViewById(R.id.tvNombreEquipo);

        }
    }
}
